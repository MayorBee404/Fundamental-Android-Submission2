package com.dicoding.ittelkom.githubuser

import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ListUser : AppCompatActivity() {
    private lateinit var rvUser : RecyclerView
    private val list = ArrayList<DataUser>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.list_user)

        rvUser = findViewById(R.id.rv_user)
        rvUser.setHasFixedSize(true)


        list.addAll(listUseres)
        showRecyclerList()

    }
    private val listUseres: ArrayList<DataUser>
        get() {
            val dataName = resources.getStringArray(R.array.data_name)
            val dataUsername = resources.getStringArray(R.array.data_username)
            val dataLocation = resources.getStringArray(R.array.data_location)
            val dataCompany = resources.getStringArray(R.array.data_company)
            val dataFollowers = resources.getStringArray(R.array.data_followers)
            val dataFollowing = resources.getStringArray(R.array.data_following)
            val dataAvatar = resources.obtainTypedArray(R.array.data_avatar)
            val listUser = ArrayList<DataUser>()
            for (i in dataName.indices) {
                val user = DataUser(dataName[i],dataUsername[i],dataLocation[i],dataCompany[i],
                    dataFollowers[i],dataFollowing[i],dataAvatar.getResourceId(i, -1))
                listUser.add(user)
            }
            return listUser
        }

    private fun showRecyclerList() {
        if (applicationContext.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            rvUser.layoutManager = GridLayoutManager(this, 2)
        } else {
            rvUser.layoutManager = LinearLayoutManager(this)
        }
        val listHeroAdapter = ListUserAdapter(list)
        rvUser.adapter = listHeroAdapter
        listHeroAdapter.setOnItemClickCallback(object : ListUserAdapter.OnItemClickCallback {
            override fun onItemClicked(data: DataUser) {
                showSelectedHero(data)
            }
        })
    }
    private fun showSelectedHero(hero: DataUser) {
        Toast.makeText(this, "Kamu memilih " + hero.name, Toast.LENGTH_SHORT).show()
    }
}