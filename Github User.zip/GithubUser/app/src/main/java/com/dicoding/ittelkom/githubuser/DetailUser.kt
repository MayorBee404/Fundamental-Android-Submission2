package com.dicoding.ittelkom.githubuser

class DetailUser {
}